*PADS-LIBRARY-PART-TYPES-V9*

AP33771CFBZ-13 SON40P300X300X80-15N-D I ANA 9 1 0 0 0
TIMESTAMP 2025.05.14.02.32.23
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" AP33771CFBZ-13
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" AP33771CFBZ-13
"Arrow Price/Stock" https://www.arrow.com/en/products/ap33771cfbz-13/diodes-incorporated?utm_currency=USD&region=nac
"Description" USB Interface IC USB Ext Power Range W-DFN3030-14 T&R 3K
"Datasheet Link" https://www.diodes.com//assets/Datasheets/AP33771C.pdf
"Geometry.Height" 0.8mm
GATE 1 15 0
AP33771CFBZ-13
1 0 U VOUT
2 0 U PWR_EN
3 0 U VCC
4 0 U ISENP
5 0 U GND_1
6 0 U FLIP
7 0 U LED
15 0 U GND_2
14 0 U V5V
13 0 U DP
12 0 U DN
11 0 U CC1
10 0 U CC2
9 0 U ISEL
8 0 U VSEL

*END*
*REMARK* SamacSys ECAD Model
19286217/351290/2.50/15/2/Integrated Circuit
